import { redirect } from "next/navigation";

export default function SettingsAliasPage() {
  redirect("/admin");
}
